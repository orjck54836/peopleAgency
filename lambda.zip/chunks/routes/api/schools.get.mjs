import { d as defineEventHandler, g as getQuery, u as useRuntimeConfig, s as setHeader, c as createError } from '../../nitro/nitro.mjs';
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, ScanCommand } from '@aws-sdk/lib-dynamodb';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@iconify/utils';
import 'consola';

const schools_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const q = getQuery(event);
  const config = useRuntimeConfig(event);
  const region = config.awsRegion || "ap-northeast-3";
  const tableName = ((_a = config.ddb) == null ? void 0 : _a.languageSchoolsTable) || process.env.DDB_LANGUAGE_SCHOOLS || "language_schools";
  const client = new DynamoDBClient({
    region,
    credentials: process.env.AWS_ACCESS_KEY_ID ? {
      accessKeyId: process.env.AWS_ACCESS_KEY_ID,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
    } : void 0
  });
  const ddb = DynamoDBDocumentClient.from(client);
  const filterParts = [];
  const exprValues = {};
  const exprNames = {};
  if (q.region) {
    filterParts.push("#region = :region");
    exprValues[":region"] = q.region;
    exprNames["#region"] = "region";
  }
  if (q.type) {
    filterParts.push("#type = :type");
    exprValues[":type"] = q.type;
    exprNames["#type"] = "type";
  }
  const hardCap = Math.min(Number((_b = q.limit) != null ? _b : 1e3), 5e3);
  const items = [];
  let ExclusiveStartKey;
  try {
    do {
      const res = await ddb.send(
        new ScanCommand({
          TableName: tableName,
          FilterExpression: filterParts.length ? filterParts.join(" AND ") : void 0,
          ExpressionAttributeValues: Object.keys(exprValues).length ? exprValues : void 0,
          ExpressionAttributeNames: Object.keys(exprNames).length ? exprNames : void 0,
          ExclusiveStartKey,
          Limit: 1e3
          // 每頁抓 1000，再自己疊加
        })
      );
      if ((_c = res.Items) == null ? void 0 : _c.length) items.push(...res.Items);
      ExclusiveStartKey = res.LastEvaluatedKey;
      if (items.length >= hardCap) break;
    } while (ExclusiveStartKey);
    setHeader(event, "Access-Control-Allow-Origin", "*");
    setHeader(event, "Content-Type", "application/json");
    return {
      success: true,
      count: items.length,
      data: items
    };
  } catch (e) {
    console.error("DynamoDB scan error:", e);
    setHeader(event, "Access-Control-Allow-Origin", "*");
    throw createError({ statusCode: 500, statusMessage: (_d = e == null ? void 0 : e.message) != null ? _d : "DynamoDB scan failed" });
  }
});

export { schools_get as default };
//# sourceMappingURL=schools.get.mjs.map
