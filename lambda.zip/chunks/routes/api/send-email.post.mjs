import { d as defineEventHandler, r as readBody, c as createError, u as useRuntimeConfig, s as setHeader } from '../../nitro/nitro.mjs';
import { SESClient, SendEmailCommand } from '@aws-sdk/client-ses';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@iconify/utils';
import 'consola';

const sendEmail_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m;
  const body = await readBody(event);
  if (!(body == null ? void 0 : body.email) || !(body == null ? void 0 : body.name)) {
    throw createError({ statusCode: 400, statusMessage: "name & email required" });
  }
  const isRecruiting = Boolean(body.inquiryType);
  const formType = isRecruiting ? "\u4EBA\u624D\u4ECB\u7D39\u8868\u55AE" : "\u7559\u5B78\u8AEE\u8A62\u8868\u55AE";
  const textBody = isRecruiting ? `\u{1F4C4} \u3010${formType}\u3011

\u516C\u53F8\u540D\u7A31: ${(_a = body.companyName) != null ? _a : ""}
\u59D3\u540D: ${(_b = body.name) != null ? _b : ""}
\u96FB\u8A71: ${(_c = body.phone) != null ? _c : ""}
E-mail: ${(_d = body.email) != null ? _d : ""}
\u5730\u5740: ${(_e = body.cityAddress) != null ? _e : ""}
\u4E8B\u696D\u5167\u5BB9: ${(_f = body.workContent) != null ? _f : ""}
\u8AEE\u8A62\u985E\u5225: ${(_g = body.inquiryType) != null ? _g : ""}
\u88DC\u5145\u8AAA\u660E: ${(_h = body.message) != null ? _h : ""}` : `\u{1F4C4} \u3010${formType}\u3011

\u59D3\u540D: ${(_i = body.name) != null ? _i : ""}
\u96FB\u8A71: ${(_j = body.phone) != null ? _j : ""}
E-mail: ${(_k = body.email) != null ? _k : ""}
\u7559\u5B78\u8A08\u756B: ${(_l = body.message) != null ? _l : ""}`;
  const config = useRuntimeConfig(event);
  const region = config.sesRegion || "ap-northeast-3";
  const ses = new SESClient({
    region,
    // 在本機開發才需要 key；部署到 Lambda 用 IAM 角色即可
    credentials: process.env.AWS_ACCESS_KEY_ID ? {
      accessKeyId: process.env.AWS_ACCESS_KEY_ID,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
    } : void 0
  });
  const Source = config.mailFrom || "aiden@forma-global.com";
  const ToAddresses = (config.mailTo || "liaiden1213@gmail.com").split(",").map((s) => s.trim()).filter(Boolean);
  try {
    await ses.send(
      new SendEmailCommand({
        Source,
        Destination: { ToAddresses },
        Message: {
          Subject: { Data: `\u{1F514} \u8868\u55AE\u63D0\u4EA4\u901A\u77E5 - ${formType}` },
          Body: { Text: { Data: textBody } }
        }
      })
    );
    setHeader(event, "Access-Control-Allow-Origin", "*");
    return { success: true, message: "\u90F5\u4EF6\u5DF2\u767C\u9001" };
  } catch (err) {
    console.error("SES send error:", err);
    setHeader(event, "Access-Control-Allow-Origin", "*");
    throw createError({ statusCode: 500, statusMessage: (_m = err == null ? void 0 : err.message) != null ? _m : "send failed" });
  }
});

export { sendEmail_post as default };
//# sourceMappingURL=send-email.post.mjs.map
